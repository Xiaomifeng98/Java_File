package com.Nvwa;

//�׳�UnsupportedPersonException�쳣
@SuppressWarnings("serial")
public class UnsupportedPersonException extends Exception {
	public UnsupportedPersonException(){
		
	}
	
	public UnsupportedPersonException(String message){
		super(message);
	}

}
